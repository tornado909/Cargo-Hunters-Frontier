# Universal Repair Kit v0.1.2: red max condition repair TEST
This is an experimental sidecar DLL only; requires matching
Cargo Hunters 0.26.38.59, Frontier 0.6.0 and previously fixed
Universal Repair Kit 0.1.2 workshop native category filter.
Do not install while the game is running. Back up original DLL.
The existing single-use kit template ID and 5000-credit price are unchanged.
The v0.1.1 plugin repaired maximum condition AFTER native item DTO
serialization; the client kept the red bar despite a server log saying
"MAX_RESTORED". v0.1.2 sets max condition INSIDE a verified original
RestoreConditionOperation -> ConditionComponent.Repair call, BEFORE DTO
serialization. It logs redRemaining/MaxValue and verifies native kit spending.
This version builds on ASC-AI with game-matching BepInEx IL2CPP refs:
0 errors, 0 warnings. Native application, saving/reload, host+guest
sync are STILL UNVERIFIED. Test only in isolated game/runtime first.
Keep identical packs and addon on host/guest.
Source PR: https://github.com/tornado909/Cargo-Hunters-Frontier/pull/7
