# Frontier Universal Repair Kit — 0.1.2 FILTER FIX (TEST)
For Cargo Hunters 0.26.38.59 + FrontierPack 0.6.0 with same versions on all Steam peers.

IMPORTANT: This package replaces the broken 0.1.1 target filter (which required
subcategory 102 for ALL items, preventing combination with head and weapons).
The native addon DLL itself remains 0.1.1; this release repairs the workshop
source JSON and its checksums, not the executable. Existing kit template ID
and price (5,000 credits) are unchanged.

1. EXIT the game completely on BOTH computers.
2. Back up BepInEx/plugins/FrontierPack/modules/workshop/*.json
   and BepInEx/plugins/FrontierUniversalRepairKit if present.
3. Extract the archive into the game root; permit overwrite of only
   three workshop JSON files and the same UniversalRepairKit addon DLL.
4. Start game. Workshop compiler will rebuild compiled/ automatically.
5. Verify target selection on HEAD, weapons and armor.
6. Confirm REAL item consumption and permanent maximum durability repair
   before considering this production-ready.

Rollback: restore three workshop source JSON files and previous addon folder.
Do not reset saves. In multiplayer every player requires the same plugin pack.

NOTE: Startup, catalog registration and filter fixture checks PASSED.
Actual in-game kit application and post-save permanent red-bar restoration
are NOT yet verified. Report UI errors and BepInEx LogOutput for followup.
Source: https://github.com/tornado909/Cargo-Hunters-Frontier/pull/7
