# Frontier — Universal Repair Kit 0.1.1 (TEST)
Apply only to Cargo Hunters 0.26.38.59 with the same FrontierPack 0.6.0 installed.
Close the game on EACH PC first, back up BepInEx/plugins/FrontierPack/modules/workshop
and any preexisting FrontierUniversalRepairKit folder.
Extract the BepInEx folder of this ZIP into the game directory (overwrite
only its 3 workshop source JSON files; the kit DLL is in its own new directory).
Do NOT copy or overwrite game saves. Compiled JSON is regenerated on startup.
The shop sells the kit for approximately 5,000 credits; workshop has a craft recipe.
Native catalog and sidecar startup tested. Restoration of previously lost maximum
condition has not yet been accepted by a real purchase/use test, and multiplayer
consumption has not been accepted on two PCs. Experimental only.
Install on both host and guest or the Frontier pack compatibility check may block JOIN.
Source: https://github.com/tornado909/Cargo-Hunters-Frontier/pull/7
Rollback: restore the 3 workshop source files from backups and disable the new
FrontierUniversalRepairKit DLL; do not reset saves.
