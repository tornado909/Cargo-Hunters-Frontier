Frontier Survivor Wear Guard 0.1.3 — TEST ONLY

Install only to an isolated test Cargo Hunters installation.
BepInEx/plugins/FrontierSurvivorWearGuard/Frontier.SurvivorWearGuard.dll
Do not remove or replace Frontier.Survivor.dll. The target base Survivor 0.2.0 SHA256 is:
aa77a6b3f3f4b5f4d3d24bbf841371de6d9ba72cf7e0681db80de7c7114ebb92

Same addon version must be installed on host and guest for multiplayer evaluation.
This version has proven stable server firearm condition and >=1000 prevented
condition decrements in a controlled solo Survivor run, but no actual 2-PC
host+guest raid acceptance and no normal-mode live regression yet.
Keep a backup. Delete only the added WearGuard folder for rollback.
Source: https://github.com/tornado909/Cargo-Hunters-Frontier/pull/6
