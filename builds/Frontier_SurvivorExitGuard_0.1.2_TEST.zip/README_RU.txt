Frontier Survivor Exit Guard 0.1.2 — TEST ONLY
Crash evidence: AccessViolationException in SurvivorRun.Tick ->
EntityManager.GetComponentData<Translation> during evacuation.
Designed for Cargo Hunters 0.26.38.59 with installed Survivor 0.2.0.
Base Survivor.dll SHA256:
aa77a6b3f3f4b5f4d3d24bbf841371de6d9ba72cf7e0681db80de7c7114ebb92
No Save mutation / no modification of original Survivor.dll.
Copy BepInEx folder into game root, close game beforehand.
Use identical plugin on host/guest. Rollback is removal of this one addon folder.
Native test: 162 seconds active Survivor, 57 kills, 0 BepInEx errors,
plus 4009 managed exit-state checks; a real evacuation was NOT observed.
Version is EXPERIMENTAL, not declared stable or multiplayer-tested.
Source and issue: https://github.com/tornado909/Cargo-Hunters-Frontier/pull/8
